from django.db import models



class Patient(models.Model):
    name = models.CharField(max_length=10)
    username = models.CharField(unique=True,max_length=25)
    email = models.EmailField(max_length=25)
    password = models.CharField(max_length=25)
    address = models.CharField(max_length=30)
    
