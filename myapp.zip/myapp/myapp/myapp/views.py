#made by me
from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages 
from django.contrib.auth import authenticate,login,logout
from django.db import models
from myapp.models import Patient

def sign(request):  
    return render(request,"sign.html");

def home(request):
    return render(request,"home.html");

def myprofile(request):
    us=request.POST['tarea']
    ms = us.replace('Welcome ', '')
    uuser = Patient.objects.get(username=ms)

    return render(request,"myprofile.html",{'obj':uuser});

def handleSignup(request):
  
    if request.method == "POST":
        
        name = request.POST['name']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        address = request.POST['address']

        #checks
        if len(username)>10:
            messages.error(request,"Username must be less than 10 characters")
            return redirect("sign")
        
        #Create Patient to Database
        myuser = Patient(name=name,username=username,email=email,password=password,address=address)
        myuser.save()
        
        messages.success(request,"SignUp Successfull")
        return redirect('sign')

    else:
        return HttpResponse("404 Not FOund")    


def handleLogin(request):
    if request.method == "POST":
        
        loginusername2 = request.POST['loginusername']
        loginpassword2 = request.POST['loginpassword']
        
        myuser = Patient.objects.get(username=loginusername2)
        #user = authenticate(username=loginusername,password=loginpassword)

        if (myuser.password == loginpassword2):
            messages.success(request,"Successfully Logged In")
            return render(request,'home.html',{'username':loginusername2})
            #return redirect("home")
        #user = authenticate(username=loginusername,password=loginpassword)

        #if user is not None:
         #   login(request,user)
          #  messages.success(request,"Successfully Logged In")
           # return redirect("home")
        else:
            messages.error(request,"Invalid Credentials")
            return redirect("sign")
    
    return HttpResponse("handleLogin");

def handleLogout(request):
    logout(request)
    messages.success(request,"Logout Successfull")
    return redirect("sign")
        
    return HttpResponse("handleLogout")


#def chan(request):

    #return render(request,"chan.html");    



def updateuserinfo(request):
    username=request.POST['username']
    name=request.POST['name']
    email=request.POST['email']
    address=request.POST['address']

    #upuser = Patient.objects.get(username=username)
    #upuser=myuser(name=name,email=email,address=address)
    #myuser.save()
    messages.success(request,"Profile Updateds")    
    
        
    return render(request,"myprofile.html");    

